let config = {
    host: 'plantita.cbqcrtkcsuq7.us-east-1.rds.amazonaws.com', //endpoint con amazon
    user: 'admin', // admin
    password: 'Gabdiel123$', //contrasenia
    database: 'plant_proj'
}

module.exports = config
